// const DestinationCard = ({ destination }) => {
//   return (
//     <div
//       className="col-sm-12 col-md-6 col-lg-4 mb-4"
//       data-bs-toggle="offcanvas"
//       data-bs-target={`#offcanvas-${destination.id}`} // unique ID
//       style={{ cursor: "pointer" }}
//     >
//       {/* Card Preview */}
//       <div className="card border-0 shadow-lg rounded-4 overflow-hidden destination-card h-100">
//         <div className="position-relative">
//           <img
//             src={destination.imgUrl}
//             alt={destination.name}
//             className="w-100 destination-img"
//             style={{ height: "220px", objectFit: "cover" }}
//           />
//           <div className="position-absolute bottom-0 w-100 py-2 bg-dark bg-opacity-50 text-center text-white fw-bold fs-5">
//             {destination.name}
//           </div>
//         </div>
//       </div>

//       {/* Offcanvas Detail View */}
//       <div
//         className="offcanvas offcanvas-bottom"
//         tabIndex="-1"
//         id={`offcanvas-${destination.id}`}
//         aria-labelledby={`offcanvasLabel-${destination.id}`}
//         style={{ height: "90vh" }}
//       >
//         {/* Header */}
//         <div className="offcanvas-header border-bottom">
//           <h4
//             className="offcanvas-title text-primary fw-bold"
//             id={`offcanvasLabel-${destination.id}`}
//           >
//             {destination.name}
//           </h4>
//           <button
//             type="button"
//             className="btn-close"
//             data-bs-dismiss="offcanvas"
//             aria-label="Close"
//           ></button>
//         </div>

//         {/* Body */}
//         <div className="offcanvas-body">
//           {/* Hero Image */}
//           <img
//             src={destination.imgUrl}
//             alt={destination.name}
//             className="img-fluid rounded-4 shadow-sm mb-4"
//             style={{ maxHeight: "280px", width: "100%", objectFit: "cover" }}
//             onError={(e) => {
//               e.target.src =
//                 "https://images.unsplash.com/photo-1506748686214-e9df14d4d9d0?auto=format&fit=crop&w=800&q=80";
//             }}
//           />

//           {/* About Section */}
//           <h5 className="text-dark fw-bold mt-3">About</h5>
//           <p className="text-muted">{destination.detailedDescription}</p>

//           {/* Best Time & Highlights */}
//           <div className="row mt-4">
//             <div className="col-md-6 mb-3">
//               <h6 className="text-primary fw-bold">
//                 <i className="bi bi-clock me-2 text-secondary"></i>
//                 Best Time to Visit
//               </h6>
//               <p className="text-muted">{destination.bestTimeToVisit}</p>
//             </div>
//             <div className="col-md-6 mb-3">
//               <h6 className="text-primary fw-bold">
//                 <i className="bi bi-sun me-2 text-warning"></i>
//                 Highlights
//               </h6>
//               <ul className="list-unstyled">
//                 {destination.highlights.map((item, idx) => (
//                   <li key={idx} className="text-muted">
//                     <i className="bi bi-check-circle-fill text-success me-2"></i>
//                     {item}
//                   </li>
//                 ))}
//               </ul>
//             </div>
//           </div>

//           {/* Services */}
//           {destination.services?.length > 0 && (
//             <div className="mt-4">
//               <h6 className="text-primary fw-bold mb-3">
//                 <i className="bi bi-gift-fill me-2 text-danger"></i>
//                 Services We Provide
//               </h6>
//               <div className="row">
//                 {destination.services.map((service, idx) => (
//                   <div key={idx} className="col-md-6 col-sm-12 mb-2">
//                     <div className="alert alert-light border shadow-sm p-2 d-flex align-items-center">
//                       <i className="bi bi-check-circle-fill text-success me-2"></i>
//                       <span>{service}</span>
//                     </div>
//                   </div>
//                 ))}
//               </div>
//             </div>
//           )}

//           {/* Packages */}
//           <div className="card shadow-sm mt-4 border-0 rounded-4">
//             <div className="card-header bg-primary text-white fw-bold">
//               Available Packages
//             </div>
//             <div className="card-body">
//               <ul className="list-group list-group-flush">
//                 {destination.packages.map((p, idx) => (
//                   <li
//                     key={idx}
//                     className="list-group-item d-flex justify-content-between align-items-center"
//                   >
//                     {p.name}
//                     <span className="badge bg-primary rounded-pill">
//                       {p.price}
//                     </span>
//                   </li>
//                 ))}
//               </ul>
//             </div>
//             <div className="card-footer bg-light">
//               <button className="btn btn-primary w-100 fw-bold shadow-sm">
//                 Book Now
//               </button>
//             </div>
//           </div>

//           {/* Why Choose */}
//           <div className="card mt-4 shadow-sm border-0 rounded-4">
//             <div className="card-header bg-success text-white fw-bold">
//               Why Choose {destination.name}?
//             </div>
//             <div className="card-body">
//               <ul className="list-unstyled text-muted">
//                 <li>✔️ Best price guarantee</li>
//                 <li>✔️ Verified customer reviews</li>
//                 <li>✔️ 24/7 customer support</li>
//                 <li>✔️ Free cancellation up to 30 days</li>
//               </ul>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default DestinationCard;

const DestinationCard = ({ destination }) => {
  const fallbackImage =
    "https://images.unsplash.com/photo-1506748686214-e9df14d4d9d0?auto=format&fit=crop&w=800&q=80";

  const handleImageError = (e) => {
    e.target.src = fallbackImage;
  };

  return (
    <div
      className="col-sm-12 col-md-6 col-lg-4 mb-4 destination-card-wrapper"
      data-bs-toggle="modal"
      data-bs-target={`#modal-${destination.id}`}
      style={{ cursor: "pointer" }}
    >
      {/* Card Preview */}
      <div className="card border-0 shadow-lg rounded-4 overflow-hidden h-100 destination-card">
        <div className="position-relative">
          <img
            src={destination.imgUrl || fallbackImage}
            alt={destination.name}
            className="w-100 destination-img"
            style={{ height: "220px", objectFit: "cover" }}
            onError={handleImageError}
          />
          <div className="position-absolute bottom-0 w-100 py-2 bg-dark bg-opacity-50 text-center text-white fw-bold fs-5">
            {destination.name}
          </div>
        </div>
      </div>

      {/* Modal Popup */}
      <div
        className="modal fade"
        id={`modal-${destination.id}`}
        tabIndex="-1"
        aria-labelledby={`modalLabel-${destination.id}`}
        aria-hidden="true"
      >
        <div className="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
          <div className="modal-content rounded-4 border-0 shadow">
            {/* Header */}
            <div className="modal-header border-0 pb-0">
              <h5
                className="modal-title text-primary fw-bold"
                id={`modalLabel-${destination.id}`}
              >
                {destination.name}
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>

            {/* Body */}
            <div className="modal-body">
              {/* Hero Image */}
              <img
                src={destination.imgUrl || fallbackImage}
                alt={destination.name}
                className="img-fluid rounded-3 shadow-sm mb-4"
                style={{
                  maxHeight: "240px",
                  width: "100%",
                  objectFit: "cover",
                }}
                onError={handleImageError}
              />

              {/* About Section */}
              <h6 className="fw-bold text-dark">About</h6>
              <p className="text-muted">{destination.detailedDescription}</p>

              {/* Best Time & Highlights */}
              <div className="row mt-3 text-center">
                {/* Best Time to Visit */}
                <div className="col-md-6 mb-3 mb-md-0">
                  <h6 className="text-primary fw-bold mb-2">
                    <i className="bi bi-clock me-2 text-secondary"></i>
                    Best Time to Visit
                  </h6>
                  <p className="text-muted mb-0">
                    {destination.bestTimeToVisit}
                  </p>
                </div>

                {/* Highlights */}
                <div className="col-md-6">
                  <h6 className="text-primary fw-bold mb-2">
                    <i className="bi bi-sun me-2 text-warning"></i>
                    Highlights
                  </h6>
                  <ul className="list-unstyled mb-0 d-inline-block text-start">
                    {destination.highlights.map((item, idx) => (
                      <li key={idx} className="mb-2 d-flex align-items-start">
                        <i className="bi bi-check-circle-fill text-success me-2 mt-1"></i>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Services */}
              {destination.services?.length > 0 && (
                <div className="mt-3">
                  <h6 className="text-primary fw-bold mb-2">
                    <i className="bi bi-gift-fill me-2 text-danger"></i>
                    Services We Provide
                  </h6>
                  <div className="row">
                    {destination.services.map((service, idx) => (
                      <div key={idx} className="col-md-6 col-sm-12 mb-2">
                        <div className="border rounded-3 p-2 bg-light d-flex align-items-center">
                          <i className="bi bi-check-circle-fill text-success me-2"></i>
                          <span>{service}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Packages */}
              {destination.packages?.length > 0 && (
                <div className="mt-4">
                  <h6 className="text-primary fw-bold mb-2">
                    Available Packages
                  </h6>
                  <ul className="list-group">
                    {destination.packages.map((p, idx) => (
                      <li
                        key={idx}
                        className="list-group-item d-flex justify-content-between align-items-center"
                      >
                        {p.name}
                        <span className="badge bg-primary rounded-pill">
                          {p.price}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DestinationCard;
